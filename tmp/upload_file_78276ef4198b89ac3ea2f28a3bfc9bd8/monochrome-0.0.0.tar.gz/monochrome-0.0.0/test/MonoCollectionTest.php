<?php

require_once 'class/MonoCollection.php';

$MC = new MonoCollection;

print_r($MC);

?>
