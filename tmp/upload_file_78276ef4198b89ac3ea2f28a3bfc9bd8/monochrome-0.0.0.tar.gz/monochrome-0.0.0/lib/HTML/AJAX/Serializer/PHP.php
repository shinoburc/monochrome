<?php
// $Id$
/**
 * PHP Serializer
 *
 * @category   HTML
 * @package    AJAX
 * @author     Arpad Ray <arpad@php.net>
 * @copyright  2005 Arpad Ray
 * @license    http://www.opensource.org/licenses/lgpl-license.php  LGPL
 * @version    Release: @package_version@
 * @link       http://pear.php.net/package/HTML_AJAX
 */
class HTML_AJAX_Serializer_PHP 
{
    
    function serialize($input) 
    {
        return serialize($input);
    }

    function unserialize($input) 
    {
        return unserialize($input);
    }
}
/* vim: set expandtab tabstop=4 shiftwidth=4 softtabstop=4: */
?>
