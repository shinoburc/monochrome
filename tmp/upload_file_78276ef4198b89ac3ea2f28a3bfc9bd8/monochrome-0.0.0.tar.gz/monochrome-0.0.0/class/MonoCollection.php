<?php

/* $Id$ */

require_once 'class/MonoIterator.php';

class MonoCollection{
    public $monos = array();

    public function __construct($monos = array()){
        $this->monos = $monos;
    }

    public function appendMono(Mono $mono){
        $this->monos[count($this->monos)] = $mono;
    }

    public function getLength(){
        return count($this->monos);
    }

    public function getMonoAt($index){
        return $this->monos[$index];
    }

    public function getIterator(){
        $arrayobject = new ArrayObject($this->monos);
        return $arrayobject->getIterator();
    }
}

?>
