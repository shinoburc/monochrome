delete from monos;
delete from int_associations;
delete from float_associations;
delete from text_associations;
delete from timestamp_associations;
delete from clob_associations;
delete from blob_associations;
delete from alias_associations;
